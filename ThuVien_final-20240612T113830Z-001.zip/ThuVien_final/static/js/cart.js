document.addEventListener('DOMContentLoaded', function () {
    const cartButton = document.getElementById('cart-button');
    const cartBox = document.getElementById('cart-box');
    const closeCartButton = document.getElementById('close-cart');
    const deleteAllButton = document.getElementById('delete-all');
    const cartCount = document.getElementById('cart-count');
    const cartItemsList = document.getElementById('cart-items');
    const totalPriceElement = document.getElementById('total-price');
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];

    // Initialize cart
    updateCartCount();
    updateCartItems();
    updateTotalPrice();

    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', function (event) {
            event.preventDefault();
            const productCard = this.closest('.card');
            const productName = productCard.querySelector('.fw-bolder').textContent;
            const productImage = productCard.getAttribute('data-image');
            const productPrice = parseFloat(productCard.getAttribute('data-price'));
            const productStatus = parseFloat(productCard.getAttribute('data-status'));
            addToCart(productName, productImage, productPrice, productStatus);
        });
    });

    cartButton.addEventListener('click', function () {
        cartBox.classList.toggle('show');
    });

    closeCartButton.addEventListener('click', function () {
        cartBox.classList.remove('show');
    });

    deleteAllButton.addEventListener('click', function () {
        cartItems = [];
        updateCartCount();
        updateCartItems();
        updateTotalPrice();
        saveCartToLocalStorage();
    });

    function addToCart(productName, productImage, productPrice, productStatus) {
        const item = {
            id: cartItems.length,
            name: productName,
            image: productImage,
            price: productPrice,
            status: productStatus

        };
        cartItems.push(item);
        updateCartCount();
        updateCartItems();
        updateTotalPrice();
        saveCartToLocalStorage();
    }

    function removeFromCart(itemId) {
        cartItems = cartItems.filter(item => item.id !== itemId);
        updateCartCount();
        updateCartItems();
        updateTotalPrice();
        saveCartToLocalStorage();
    }

    function updateCartCount() {
        cartCount.textContent = cartItems.length;
    }

    function updateCartItems() {
        cartItemsList.innerHTML = '';
        cartItems.forEach(item => {
            const li = document.createElement('li');
            li.innerHTML = `<img src="${item.image}" class="cart-item-img" alt="${item.name}">
                        <div class="cart-item-details">
                            ${item.name}
                            <span class="cart-item-price">₫${item.price.toFixed(2)}</span>
                            <span class="cart-item-status">Chờ Xử Lý</span>
                        </div>
                        <button class="delete-button" data-id="${item.id}">&times;</button>`;
            cartItemsList.appendChild(li);
        });

        document.querySelectorAll('.delete-button').forEach(button => {
            button.addEventListener('click', function () {
                const itemId = parseInt(this.getAttribute('data-id'));
                removeFromCart(itemId);
            });
        });
    }

    function updateTotalPrice() {
        const total = cartItems.reduce((sum, item) => sum + item.price, 0);
        
    }

    function saveCartToLocalStorage() {
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    }
});
document.addEventListener('DOMContentLoaded', function () {
    const categoryMenu = document.getElementById('navbarDropdown');
    const subMenuItems = document.querySelectorAll('.dropdown-item');

    categoryMenu.addEventListener('click', function () {
        // Logic to handle the click event on the main category menu
    });

    subMenuItems.forEach(function (item) {
        item.addEventListener('click', function () {
            const selectedCategory = this.textContent;
            console.log(`Selected Category: ${selectedCategory}`);
            // Logic to handle the click event on each sub-menu item
        });
    });
});

document.getElementById('search-form').addEventListener('submit', function(event) {
    event.preventDefault();
    const query = document.getElementById('search-input').value.toLowerCase();
    const results = products.filter(product => 
        product.category.toLowerCase().includes(query) || 
        product.name.toLowerCase().includes(query) ||
        product.author.toLowerCase().includes(query)
    );
    displayResults(results);
});

function displayResults(results) {
    const resultsContainer = document.getElementById('search-results');
    resultsContainer.innerHTML = '';
    if (results.length === 0) {
        resultsContainer.innerHTML = '<p>No products found</p>';
        return;
    }

    results.forEach(product => {
        const resultItem = document.createElement('div');
        resultItem.classList.add('search-result-item');
        let productPage;
        switch(product.category) {
            case 'lãng mạn':
                productPage = 'langman';
                break;
            case 'giật gân':
                productPage = 'giatgan';
                break;
                
            default:
                productPage = 'sci';    
        }
        resultItem.innerHTML = `
            <a href="${productPage}">
                <img src="${product.image}" alt="${product.name}">
                <p>${product.name}</p>
                <p>Category: ${product.category}</p>
                <p>Author: ${product.author}</p>
            </a>
        `;
        resultsContainer.appendChild(resultItem);
    });
}


const products = [

    { name: "Cliche A Love Story", category: "lãng mạn", image: "static/img/cliche.jpg", author: "Author A" },
    { name: "The Ocean Storm", category: "lãng mạn", image: "static/img/ocean.jpg", author: "Author B" },
    { name: "Lời Hẹn Ước Của Chúng Ta", category: "lãng mạn", image: "static/img/hen.jpg", author: "Rika" },
    { name: "Bí Mật Nơi Góc Tối", category: "lãng mạn", image: "static/img/mystery.jpg", author: "Nhĩ Đông Thố Tử" },
    { name: "Nếu Không Là Tình Yêu", category: "lãng mạn", image: "static/img/ro1.jpg", author: "Diệp Lạc Vô Tâm" },
    { name: "Gặp Anh Vào Mùa Thu Năm Ấy", category: "lãng mạn", image: "static/img/thu.jpg", author: "Author A" },
    { name: "Shallow Season", category: "lãng mạn", image: "static/img/season.jpg", author: "Author B" },
    { name: "The Gratitude", category: "lãng mạn", image: "static/img/gratitude.jpg", author: "Nancy Brown" },
    { name: "Mãi Mãi Là Bao Xa", category: "lãng mạn", image: "static/img/ro6.jpg", author: "Diệp Lạc Vô Tâm" },
    { name: "Phía Sau Ký Ức Tận Cùng Tháng Năm", category: "lãng mạn", image: "static/img/ro7.jpg", author: "Diệp Lạc Vô Tâm" },
    {name: "Mây Bay Qua Trời Em Qua Tìm Tôi", category: "lãng mạn", image: "static/img/ro8.jpg", author: "Mộc Thanh Vũ" },
    { name: "Sau Người Có Tôi", category: "lãng mạn", image: "static/img/ro9.jpg", author: "Author A" },
    { name: "Bên Nhau Trọn Đời", category: "lãng mạn", image: "static/img/ro10.jpg", author: "Cố Mạn" },
    { name: "Yêu Không Bến Bờ", category: "lãng mạn", image: "static/img/ro11.jpg", author: "Author A" },
    
    { name: "Mình Nói Gì Khi Nói Về Hạnh Phúc?", category: "lãng mạn", image: "static/img/hanh.jpg", author: "Quyền Phan" },
    { name: "Không Có Ước Mơ", category: "lãng mạn", image: "static/img/uocmo.jpg", author: "Author A" },
   
    { name: "Sông Núi Đượm Tình", category: "lãng mạn", image: "static/img/tin.jpg", author: "Author B" },
    { name: "Hồ Ly Biết Yêu", category: "lãng mạn", image: "static/img/ro3.jpg", author: "Diệp Lạc Vô Tâm" },
    { name: "Ngủ Cùng Sói", category: "lãng mạn", image: "static/img/ro4.jpg", author: "Diệp Lạc Vô Tâm" },
    { name: "Yêu Em Từ Cái Nhìn Đầu Tiên", category: "lãng mạn", image: "static/img/ro5.jpg", author: "Cố Mạn" },
    {name: "Mây Bay Qua Trời Em Qua Tìm Tôi", category: "lãng mạn", image: "static/img/ro8.jpg", author: "Mộc Thanh Vũ" },
    { name: "Sau Người Có Tôi", category: "lãng mạn", image: "static/img/ro9.jpg", author: "Author A" },
   
    { name: "Yêu Không Bến Bờ", category: "lãng mạn", image: "static/img/ro11.jpg", author: "Author A" },
   
    { name: "Mình Nói Gì Khi Nói Về Hạnh Phúc?", category: "lãng mạn", image: "static/img/hanh.jpg", author: "Quyền Phan" },
    { name: "Không Có Ước Mơ", category: "lãng mạn", image: "static/img/uocmo.jpg", author: "Author A" },
    { name: "Không Gì Có Thể Thay Thế Em", category: "lãng mạn", image: "static/img/em.jpg", author: "Cố Mạn" },
    { name: "Sông Núi Đượm Tình", category: "lãng mạn", image: "static/img/tin.jpg", author: "Author B" },
    { name: "T bất lực vcl, đ bao h giúp nữa!", category: "lãng mạn", image: "static/img/qp.jpg", author: "Quyền Phan" },
 

    { name: "Bí Ẩn Sau Cánh Cửa Nhà Xác", category: "giật gân", image: "static/img/xac.jpg", author: "Carla Valentine" },
    { name: "Câu Chuyện Đằng Sau Bác Sĩ Tâm Thần", category: "giật gân", image: "static/img/tam.jpg", author: "Nguyễn Trung Nghĩa" },
    { name: "Rừng Na Uy", category: "giật gân", image: "static/img/nauy.jpg", author: "Haruki Murakami" },
    { name: "Người Truyền Ký Ức", category: "giật gân", image: "static/img/uc.jpg", author: "Lois Lowry" },
    {name: "Tokyo Hoàng Đạo Án", category: "giật gân", image: "static/img/tokyo.jpg", author: "Hoàng Minh Tường" },
    { name: "Lai Lịch", category: "giật gân", image: "static/img/lai.jpg", author: "Patrick Modiano" },
    { name: "Người Hạt Dẻ", category: "giật gân", image: "static/img/hat.jpg", author: "Soren Sveistrup" },
    
    { name: "Hố Đen Tâm Lý", category: "giật gân", image: "static/img/ly.jpg", author: "Peter Jongho Na" },



    { name: "Harry Potter Và Hòn Đá Phù Thuỷ", category: "sci-fi", image: "static/img/harry.jpg", author: "JK Rowling" },
    { name: "Harry Potter Và Phòng Chứa Bí Mật", category: "sci-fi", image: "static/img/hr2.jpg", author: "JK Rowling" },
    { name: "Harry Potter Và Tù Nhân Azkaban", category: "sci-fi", image: "static/img/hr3.jpg", author: "JK Rowling" },
    { name: "Infinite Worlds", category: "sci-fi", image: "static/img/hr4.jpg", author: "Author A" },
    { name: "Fantastic Beasts And Where To Find Them", category: "sci-fi", image: "static/img/hr6.jpg", author: "JK Rowling" },
    { name: "Fantastic Beast: Tội Ác Của Grindelwald", category: "sci-fi", image: "static/img/hr7.jpg", author: "JK Rowling" },
    
];


;





