CREATE TABLE Accounts
(
    account_id character varying(50) NOT NULL,
    username character varying(50) COLLATE pg_catalog."default" NOT NULL,
    password_id character varying(50) COLLATE pg_catalog."default" NOT NULL,
    is_active boolean NOT NULL,
    PRIMARY KEY (account_id)
);

CREATE TABLE Age_groups
(
    age_group_id character varying(50) NOT NULL,
    age_group_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    min_age integer NOT NULL,
    max_age integer NOT NULL,
    PRIMARY KEY (age_group_id)
);

CREATE TABLE Authors
(
    author_id character varying(50) NOT NULL,
    first_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    last_name character varying(255) COLLATE pg_catalog."default" NOT NULL,
    nationality character varying(255) COLLATE pg_catalog."default" NOT NULL,
    PRIMARY KEY (author_id)
);

CREATE TABLE Books
(
    book_id character varying(50) NOT NULL,
    book_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    age_group_id character varying(50) NOT NULL,
    genre_id character varying(50) NOT NULL,
    author_id character varying(50) NOT NULL,
    publisher_id character varying(50) NOT NULL,
    publication_year integer NOT NULL,
    available integer NOT NULL,
    quantity integer NOT NULL,
    price integer NOT NULL,
    PRIMARY KEY (book_id)
);

CREATE TABLE Genres
(
    genre_id character varying(50) NOT NULL,
    genre_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    PRIMARY KEY (genre_id)
);

CREATE TABLE Book_Author
(
	book_id character varying(50) NOT NULL,
	author_id character varying(50) NOT NULL,
	PRIMARY KEY (book_id, author_id),
	FOREIGN KEY (book_id) REFERENCES Books(book_id),
	FOREIGN KEY (author_id) REFERENCES Authors(author_id)
);

CREATE TABLE Book_Genre
(
	book_id character varying(50) NOT NULL,
	genre_id character varying(50) NOT NULL,
	PRIMARY KEY (book_id, genre_id),
	FOREIGN KEY (book_id) REFERENCES Books(book_id),
	FOREIGN KEY (genre_id) REFERENCES Genres(genre_id)
);

CREATE TABLE Employees
(
    first_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    last_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    date_of_birth date NOT NULL,
    phone character varying(50) COLLATE pg_catalog."default" NOT NULL,
    address character varying(50) COLLATE pg_catalog."default" NOT NULL,
    email character varying(50) COLLATE pg_catalog."default" NOT NULL
) INHERITS (Accounts);

CREATE TABLE Members
(
    first_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    last_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    address character varying(50) COLLATE pg_catalog."default" NOT NULL,
    date_of_birth date NOT NULL,
    phone character varying(50) COLLATE pg_catalog."default" NOT NULL,
    email character varying(50) COLLATE pg_catalog."default" NOT NULL,
    expire_date date NOT NULL
) INHERITS (Accounts);

CREATE TABLE Borrowing_Receipts
(
    receipt_id character varying(50) NOT NULL,
    employee_account_id character varying(50) COLLATE pg_catalog."default" NOT NULL,
    member_account_id character varying(50) COLLATE pg_catalog."default" NOT NULL,
    fee_id character varying(50) NOT NULL,
    borrow_date date NOT NULL,
    due_date date NOT NULL,
    return_date date NOT NULL,
    status character varying(50) COLLATE pg_catalog."default" NOT NULL,
    PRIMARY KEY (receipt_id),
    FOREIGN KEY (employee_account_id) REFERENCES Accounts(account_id),
    FOREIGN KEY (member_account_id) REFERENCES Accounts(account_id)
);

CREATE TABLE Borrowed_Books
(
    receipt_id character varying(50) NOT NULL,
    book_id character varying(50) NOT NULL,
    quantity integer NOT NULL,
	PRIMARY KEY (receipt_id, book_id),
	FOREIGN KEY (receipt_id) REFERENCES Borrowing_Receipts(receipt_id),
	FOREIGN KEY (book_id) REFERENCES Books(book_id)
);

CREATE TABLE Fees
(
    fee_id character varying(50) NOT NULL,
    name_fee character varying(255) COLLATE pg_catalog."default" NOT NULL,
    fee integer NOT NULL,
    PRIMARY KEY (fee_id)
);

CREATE TABLE Publishers
(
    publisher_id character varying(50) NOT NULL,
    publisher_name character varying(50) COLLATE pg_catalog."default" NOT NULL,
    publisher_address character varying(50) COLLATE pg_catalog."default" NOT NULL,
    publisher_phone character varying(50) COLLATE pg_catalog."default" NOT NULL,
    PRIMARY KEY (publisher_id)
);

ALTER TABLE Books
    ADD CONSTRAINT books_age_group_id_foreign FOREIGN KEY (age_group_id)
    REFERENCES Age_groups (age_group_id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION;

ALTER TABLE Books
    ADD CONSTRAINT books_publisher_id_foreign FOREIGN KEY (publisher_id)
    REFERENCES Publishers (publisher_id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION;

ALTER TABLE Borrowing_Receipts
    ADD CONSTRAINT "borrowing receipts_fee_id_foreign" FOREIGN KEY (fee_id)
    REFERENCES Fees (fee_id) MATCH SIMPLE
    ON UPDATE NO ACTION
    ON DELETE NO ACTION;